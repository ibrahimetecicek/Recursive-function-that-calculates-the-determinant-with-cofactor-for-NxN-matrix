

function D=determine(M,C)

[n,n]=size(M);

i=1;

while i<=n

d=0;

for j=1:n;

dd=M(i,j)*C(i,j);

d=d+dd;

end

D1(i,1)=d;

i=i+1;

end

j=1;

while j<=n

d=0;

for i=1:n;

dd=M(i,j)*C(i,j);

d=d+dd;

end

d2(1,j)=d;

j=j+1;

end

D2=transpose (d2);

D12=[D1 D2];

[m,n]=size(D12);

i=1;j=1;

while i<=m && j<=n

if abs (D12(i,j)-D12(1,1))<10^(-7)

D=D1(1);

else

D=[];

disp('Error');

break;

end

i=i+1;

j=j+1;

end