function C=cofactor(M)

[n,n]=size(M);

for i=1:n;

for j=1:n;

A=M;

A(i,:)=[];

A(:,j)=[];

C(i,j)=(-1).^(i+j)*det(A);

end

end


